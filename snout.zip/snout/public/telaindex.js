function entrarSite() {
    const welcome = document.getElementById('welcome');
    welcome.classList.add('fadeOutUp');
    setTimeout(() => {
      window.location.href = 'Tarefa.html'; 
    }, 1000); 
  }
  